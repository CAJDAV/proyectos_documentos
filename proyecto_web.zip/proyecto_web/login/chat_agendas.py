from datetime import datetime
import re

# Simulación de base de datos de citas
citas_programadas = {}

def agendar_cita(fecha, hora):
    # Formato de fecha y hora: 'dd-mm-aaaa' y 'HH:MM'
    clave_cita = f"{fecha} {hora}"
    if clave_cita in citas_programadas:
        return "Lo siento, ya hay una cita programada para esa fecha y hora."
    else:
        citas_programadas[clave_cita] = "Cita agendada"
        return "Cita agendada con éxito para el " + clave_cita

def verificar_disponibilidad(fecha, hora):
    clave_cita = f"{fecha} {hora}"
    return clave_cita not in citas_programadas

def procesar_mensaje_usuario(mensaje):
    # Expresión regular para identificar fechas y horas en el mensaje
    patron_fecha = r"\b\d{2}-\d{2}-\d{4}\b"
    patron_hora = r"\b\d{2}:\d{2}\b"
    
    fecha = re.search(patron_fecha, mensaje)
    hora = re.search(patron_hora, mensaje)
    
    if fecha and hora:
        fecha = fecha.group()
        hora = hora.group()
        # Verificar si la fecha y hora son válidas
        try:
            datetime.strptime(fecha, '%d-%m-%Y')
            datetime.strptime(hora, '%H:%M')
            if verificar_disponibilidad(fecha, hora):
                return agendar_cita(fecha, hora)
            else:
                return "La fecha y hora solicitadas no están disponibles."
        except ValueError:
            return "Por favor, ingresa una fecha y hora válidas."
    else:
        return "No pude encontrar una fecha y hora en tu mensaje."

# Ejemplo de uso
mensaje_usuario = "Quiero agendar una cita para el 15-04-2024 a las 14:00."
respuesta = procesar_mensaje_usuario(mensaje_usuario)
print(respuesta)
